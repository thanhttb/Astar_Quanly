<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
	
	<title>Phiếu thu</title>
	
	<link rel='stylesheet' type='text/css' href=" {{ asset('resources/views/invoice/css/invoices.css')}} " />
	<link rel='stylesheet' type='text/css' href=" {{ asset('resources/views/invoice/css/print.css')}} " media="print" />
	<script type='text/javascript' src=" {{ asset('resources/views/invoice/js/jquery-1.3.2.min.js')}} "></script>
	<script type='text/javascript' src=" {{ asset('resources/views/invoice/js/invoice.js')}} "></script>

</head>

<body>

	<div id="page-wrap">

		<textarea id="header">PHIẾU THU</textarea>
		
		<div id="identity">
		
            <textarea id="address">A-STAR EDUCATION CENTER
Nhà 29 ngõ 23 Phố Đỗ Quang, Trung Hòa, Cầu Giấy, Hà Nội

SĐT:043 568 1888 - 091 635 5518</textarea>

            <div id="logo">         

              
              <img id="image" src="{{asset('resources/views/invoice/images/logo.png')}}" alt="logo" />
            </div>
		
		</div>
		
		<div style="clear:both"></div>
		
		<div id="customer">

            <textarea id="customer-title">Học sinh: {{$studentInfo['lastName']}} {{$studentInfo['firstName']}}

            </textarea>

            <table id="meta">
                <tr>
                    <td class="meta-head">Invoice #</td>
                    <td><textarea></textarea></td>
                </tr>
                <tr>

                    <td class="meta-head">Date</td>
                    <td><textarea id="date">December 15, 2009</textarea></td>
                </tr>
                

            </table>
		
		</div>
		
		<table id="items">
		
		  
		  <?php 
		  		function asVnd($value){
		  			return number_format($value,'0','','.')."đ";
		  		}
		  		$total = 0;
		   ?>
		  @if(!empty($listClass))
		  <tr>
		      <th>Lớp</th>
		      <th>Miêu tả</th>
		      <th>Học phí</th>
		      <th>Số buổi</th>
		      <th>Tổng</th>
		  </tr>
<script type='text/javascript' src=" {{ asset('resources/views/invoice/js/invoice.js')}} "></script>

		  	@foreach($listClass as $className => $lessons)
		  		@foreach($lessons as $tuition => $totals)
			  		<tr class="item-row">
			  			<td class="item-name"><div class="delete-wpr"><textarea>{{$className}}</textarea><a class="delete" href="javascript:;" title="Remove row">X</a></div></td>
			  			<td class="description"><textarea>Tiền học tháng </textarea></td>
			  			<td><textarea class="cost"><?php echo $tuition; ?></textarea></td>
					    <td><textarea class="qty"><?php echo $totals['count'] ?></textarea></td>
					    <td><span class="price"><?php echo $totals['total']; $total += $totals['total']; ?></span></td>
			  		</tr>
		  		@endforeach
		  	@endforeach
				  	<tr>
				      <td colspan="2" class="blank"> </td>
				      <td colspan="2" class="total-line">Tổng Học Phí</td>
				      <td class="total-value"><div id="subtotal"><?php echo asVnd($total); ?></div></td>
				      <input type="hidden" id="total" value="{{$total}}">
				  	</tr>
		  @else
		  <th>Lý do nộp</th>	      
	      <th>Số Tiền</th>
	      
<script type='text/javascript' src=" {{ asset('resources/views/invoice/js/invoiceNonLesson.js')}} "></script>

		  <tr class="item-row">
			  			<td class="item-name"><div class="delete-wpr"><textarea></textarea><a class="delete" href="javascript:;" title="Remove row">X</a></div></td>
			  			<td class="description"><textarea>Tiền học tháng </textarea></td>
			  			<td><input type="number" class="cost"></td>
					    <td><textarea class="qty"></textarea></td>
					    <td><span class="price"></span></td>
			  		</tr>
		  	<tr id="hiderow">
		    <td colspan="5"><a id="addrow" href="javascript:;" title="Add a row">Add a row</a></td></tr>
		    <tr>
	      <td colspan="2" class="blank"> </td>
	      <td colspan="2" class="total-line">Tổng Học Phí</td>
	      <td class="total-value"><div id="subtotal"><?php echo asVnd($total); ?></div></td>
		  </tr>
		  <tr>

	      <td colspan="2" class="blank"> </td>
	      <td colspan="2" class="total-line">Total</td>
	      <td class="total-value"><div id="total">$875.00</div></td>
		  </tr>
		  @endif  
		  
		  
		  
		  
		  <tr>
		      <td colspan="2" class="blank"> </td>
		      <td colspan="2" class="total-line">Thanh Toán</td>

		      <td class="total-value"><textarea id="paid">0</textarea></td>
		  </tr>
		  <tr>
		      <td colspan="2" class="blank"> </td>
		      <td colspan="2" class="total-line balance">Số Dư</td>
		      <td class="total-value balance"><div class="due">0</div></td>
		  </tr>
		
		</table>
		
		<div id="terms">
		  <h5>Chú Ý</h5>
		  <textarea>...</textarea>
		</div>
	
	</div>
	
</body>

</html>